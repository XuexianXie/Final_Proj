/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BBX;

import BBX.Customer.CustomerDirectory;
import BBX.DeliveryMan.DeliveryManDirectory;
import BBX.food.Food;
import BBX.food.FoodOrder;
import BBX.food.FoodSupplierManager;
import BBX.food.FoodSupplierManagerDirectory;
import BBX.UserAccount.UserAccountDirectory;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author MyPC1
 */
public class EcoSystem {

    private String name;
    private static EcoSystem business;
    private ArrayList<Network> networkList;
    private int currentNetwork = 0;

    public static EcoSystem getInstance() {
        if (business == null) {
            business = new EcoSystem();
        }
        return business;
    }

    public static void setInstance(EcoSystem system) {
        business = system;
    }

    private EcoSystem() {
        name = "Food Delivery System";
        networkList = new ArrayList<Network>();
    }

    public boolean checkIfUserIsUnique(String userName) {
        //
        return this.networkList.get(currentNetwork).getUserAccountDirectory().checkIfUsernameIsUnique(userName);
    }

    public FoodSupplierManagerDirectory getRestaurantDirectory() {
        return networkList.get(currentNetwork).getFoodSupplierDirectory();
    }

    public CustomerDirectory getCustomerDirectory() {
        return networkList.get(currentNetwork).getCustomerDirectory();
    }

    public DeliveryManDirectory getDeliveryManDirectory() {
        return networkList.get(currentNetwork).getDeliveryManDirectory();
    }

    public int getCurrentNetwork() {
        return currentNetwork;
    }

    public void setCurrentNetwork(int currentNetwork) {
        this.currentNetwork = currentNetwork;
    }

    public ArrayList<Network> getNetworkList() {
        return networkList;
    }

    public UserAccountDirectory getUserAccountDirectory() {
        return networkList.get(currentNetwork).getUserAccountDirectory();
    }

    public String getName() {
        return networkList.get(currentNetwork).getName();
    }

    public List<FoodOrder> getFoodOrders(Food food) {
        List<FoodOrder> orders = new ArrayList<>();
        for (FoodSupplierManager r : getRestaurantDirectory().getList()) {
            for (FoodOrder order : r.getOrderDirectory().getList()) {
                if (order.getFood() == food) {
                    orders.add(order);
                }
            }
        }
        return orders;
    }

}
