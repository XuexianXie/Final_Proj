/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BBX.DeliveryMan;

import BBX.food.FoodOrderDirectory;
import BBX.UserAccount.UserAccount;

/**
 *
 * @author harold
 */
public class DeliveryMan {

    private UserAccount account;
    private String name;
    private String phone;

    private FoodOrderDirectory orderDirectory;

    public DeliveryMan(UserAccount account, String name, String phone) {
        this.account = account;
        this.name = name;
        this.phone = phone;

        orderDirectory = new FoodOrderDirectory();
    }

    public FoodOrderDirectory getOrderDirectory() {
        return orderDirectory;
    }

    public UserAccount getAccount() {
        return account;
    }

    public void setAccount(UserAccount account) {
        this.account = account;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    @Override
    public String toString() {
        return name + "(" + phone + ")";
    }
}
