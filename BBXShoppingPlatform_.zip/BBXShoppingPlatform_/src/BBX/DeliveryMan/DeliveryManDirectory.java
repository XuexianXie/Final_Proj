/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BBX.DeliveryMan;

import BBX.food.FoodSupplierManager;
import BBX.UserAccount.UserAccount;
import java.util.ArrayList;

/**
 *
 * @author harold
 */
public class DeliveryManDirectory {
    
    private final ArrayList<DeliveryMan> list;

    public DeliveryManDirectory() {
        this.list = new ArrayList<DeliveryMan>();
    }

    public ArrayList<DeliveryMan> getList() {
        return list;
    }

    public void add(DeliveryMan account) {
        this.list.add(account);
    }

    public DeliveryMan get(UserAccount ua) {
        for (DeliveryMan r : list) {
            if (r.getAccount().getUsername().equals(ua.getUsername())) {
                return r;
            }
        }
        return null;
    }

    public DeliveryMan search(String username) {
        for (DeliveryMan r : list) {
            if (r.getAccount().getUsername().equals(username)) {
                return r;
            }
        }
        return null;
    }

    public void delete(DeliveryMan account) {
         list.remove(account);
    }
}
