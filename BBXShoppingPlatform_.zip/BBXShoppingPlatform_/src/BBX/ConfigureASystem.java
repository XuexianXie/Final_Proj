package BBX;

import BBX.Customer.Customer;
import BBX.DeliveryMan.DeliveryMan;
import BBX.food.Food;
import BBX.food.FoodSupplierManager;
import BBX.Role.CustomerRole;
import BBX.Role.DeliveryManRole;
import BBX.Role.FoodOrderManagerRole;
import BBX.Role.FoodSupplierManagerRole;
import static BBX.Role.RoleType.FoodOrderManager;
import BBX.Role.SystemAdminRole;
import BBX.UserAccount.UserAccount;
import BBX.food.FoodOrderManager;

/**
 *
 * @author rrheg
 */
public class ConfigureASystem {

    public static EcoSystem configure() {

        EcoSystem system = EcoSystem.getInstance();

        //Create a network
        //create an enterprise
        //initialize some organizations
        //have some employees 
        //create user account
        system.getNetworkList().add(new Network("Boston"));
        system.getNetworkList().add(new Network("Seattle"));

        for (Network n : system.getNetworkList()) {
            //add two system admin
            n.getUserAccountDirectory().createUserAccount("sysadmin", "sysadmin", new SystemAdminRole());
            n.getUserAccountDirectory().createUserAccount("1", "1", new SystemAdminRole());

            //add Food Supplier
            UserAccount r1 = n.getUserAccountDirectory().createUserAccount("fs", "fs", new FoodSupplierManagerRole());
            FoodSupplierManager foodSupplier = new FoodSupplierManager(r1, "Supplier 1", "12345678", "Address 1");
            n.getFoodSupplierDirectory().add(foodSupplier);
            
            //add Food Manager
            UserAccount r2 = n.getUserAccountDirectory().createUserAccount("fo", "fo", new FoodOrderManagerRole());
            FoodOrderManager foodOrder = new FoodOrderManager(r2, foodSupplier);
            n.getFoodOrderManagerDirectory().add(foodOrder);
            
            //add menu
            foodSupplier.getFoodDirectory().add(new Food(1, "Coffee", 10));
            foodSupplier.getFoodDirectory().add(new Food(2, "Sandwich", 5));
            
            //add customer
            UserAccount c1 = n.getUserAccountDirectory().createUserAccount("user", "user", new CustomerRole());
            Customer customer = new Customer(c1, "James", "12345678", "Address user");
            n.getCustomerDirectory().add(customer);
            
            //add deliveryMan
            UserAccount d1 = n.getUserAccountDirectory().createUserAccount("delivery", "delivery", new DeliveryManRole());
            DeliveryMan deliveryMan = new DeliveryMan(d1, "Locus", "55555555");
            n.getDeliveryManDirectory().add(deliveryMan);
        }
        return system;
    }
}
