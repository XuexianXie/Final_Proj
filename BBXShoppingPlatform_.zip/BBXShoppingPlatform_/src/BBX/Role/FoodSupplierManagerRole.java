/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package BBX.Role;

import BBX.EcoSystem;
import BBX.Organization;
import BBX.UserAccount.UserAccount;
import javax.swing.JPanel;
import userinterface.FoodSupplierManagerRole.FoodRetailerWorkAreaJPanel;

/**
 *
 * @author raunak
 */
public class FoodSupplierManagerRole extends Role{

    public FoodSupplierManagerRole() {
        super(RoleType.FoodSupplierManager);
    }

    @Override
    public JPanel createWorkArea(JPanel userProcessContainer, UserAccount account, EcoSystem business) {
        return new FoodRetailerWorkAreaJPanel(userProcessContainer, EcoSystem.getInstance().getRestaurantDirectory().get(account));
    }
}
