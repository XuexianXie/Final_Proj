/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package BBX.Role;

import BBX.EcoSystem;
import BBX.Organization;
import BBX.UserAccount.UserAccount;
import userinterface.CustomerRole.CustomerAreaJPanel;
import javax.swing.JPanel;

/**
 *
 * @author raunak
 */
public class CustomerRole extends Role{

    public CustomerRole() {
        super(RoleType.Customer);
    }

    
    public JPanel createWorkArea(JPanel userProcessContainer, UserAccount account, EcoSystem business) {
        return new CustomerAreaJPanel(userProcessContainer, account);
    }
    
    
}
