/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package BBX.Role;

import BBX.EcoSystem;
import BBX.UserAccount.UserAccount;
import javax.swing.JPanel;
import userinterface.FoodOrderManagerRole.FoodOrderMangerWorkAreaJPanel;

/**
 *
 * @author raunak
 */
public class FoodOrderManagerRole extends Role{

    public FoodOrderManagerRole() {
        super(RoleType.FoodOrderManager);
    }

    @Override
    public JPanel createWorkArea(JPanel userProcessContainer, UserAccount account, EcoSystem business) {
        return new FoodOrderMangerWorkAreaJPanel(userProcessContainer, EcoSystem.getInstance().getRestaurantDirectory().get(account));
    }
}
