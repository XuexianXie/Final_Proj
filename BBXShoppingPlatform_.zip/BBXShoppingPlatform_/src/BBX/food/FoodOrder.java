/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BBX.food;

import BBX.DeliveryMan.DeliveryMan;
import BBX.Customer.Customer;
import java.time.LocalDateTime;

/**
 *
 * @author
 */
public class FoodOrder {
    private final Customer customer;
    private final Food food;
    private final FoodSupplierManager restaurant;
    private DeliveryMan deliveryMan;
    private boolean delivered = false;
    private String comments;
    
    public FoodOrder(Customer customer, Food food, FoodSupplierManager restaurant) {
        this.customer = customer;
        this.food = food;
        this.restaurant = restaurant;
    }

    public Customer getCustomer() {
        return customer;
    }

    public Food getFood() {
        return food;
    }

    public FoodSupplierManager getRestaurant() {
        return restaurant;
    }

    public boolean isDelivered() {
        return delivered;
    }

    public void setDelivered(boolean delivered) {
        this.delivered = delivered;
    }

    public DeliveryMan getDeliveryMan() {
        return deliveryMan;
    }

    public void setDeliveryMan(DeliveryMan deliveryMan) {
        this.deliveryMan = deliveryMan;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    
    
}
