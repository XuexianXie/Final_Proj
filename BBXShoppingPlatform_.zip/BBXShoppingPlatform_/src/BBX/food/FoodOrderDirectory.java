/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BBX.food;

import BBX.food.Food;
import BBX.UserAccount.UserAccount;
import java.util.ArrayList;

/**
 *
 * @author harold
 */
public class FoodOrderDirectory {
    
    private final ArrayList<FoodOrder> list;

    public FoodOrderDirectory() {
        this.list = new ArrayList<FoodOrder>();
    }

    public ArrayList<FoodOrder> getList() {
        return list;
    }

    public void add(FoodOrder account) {
        this.list.add(account);
    }

    public void delete(FoodOrder f) {
         list.remove(f);
    }
}
