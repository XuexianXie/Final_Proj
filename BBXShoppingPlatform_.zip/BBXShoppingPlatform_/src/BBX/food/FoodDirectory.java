/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BBX.food;

import BBX.food.Food;
import BBX.UserAccount.UserAccount;
import java.util.ArrayList;

/**
 *
 * @author harold
 */
public class FoodDirectory {
    
    private final ArrayList<Food> list;

    public FoodDirectory() {
        this.list = new ArrayList<Food>();
    }

    public ArrayList<Food> getList() {
        return list;
    }

    public void add(Food account) {
        this.list.add(account);
    }

    public Food search(String name) {
        for (Food r : list) {
            if (r.getName().equals(name)) {
                return r;
            }
        }
        return null;
    }

    public void delete(Food f) {
         list.remove(f);
    }
}
