/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BBX.food;

import BBX.UserAccount.UserAccount;

/**
 *
 * @author harold
 */
public class FoodSupplierManager {
    private UserAccount account;
    private String name;
    private String phone;
    private String address;
    
    private FoodDirectory foodDirectory;
    private FoodOrderDirectory orderDirectory;
    
    public FoodSupplierManager(UserAccount account, String name,String phone, String address) {
        this.account = account;
        this.name = name;
        this.phone = phone;
        this.address = address;
        
        foodDirectory = new FoodDirectory();
        orderDirectory = new FoodOrderDirectory();
    }

    public FoodDirectory getFoodDirectory() {
        return foodDirectory;
    }

    public UserAccount getAccount() {
        return account;
    }

    public FoodOrderDirectory getOrderDirectory() {
        return orderDirectory;
    }

    public void setAccount(UserAccount account) {
        this.account = account;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String toString() {
        return name;
    }
}
