/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BBX.food;

import BBX.UserAccount.UserAccount;

/**
 *
 * @author harold
 */
public class FoodOrderManager {
    private UserAccount account;
    private FoodSupplierManager supplierManager;
    private FoodOrderDirectory orderDirectory;
    
    public FoodOrderManager(UserAccount account, FoodSupplierManager supplierManager) {
        this.account = account;
        this.supplierManager = supplierManager;
        orderDirectory = new FoodOrderDirectory();
    }

    public UserAccount getAccount() {
        return account;
    }

    public FoodOrderDirectory getOrderDirectory() {
        return orderDirectory;
    }

    public void setAccount(UserAccount account) {
        this.account = account;
    }
}
