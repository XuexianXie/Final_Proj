/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BBX.food;

import BBX.UserAccount.UserAccount;
import java.util.ArrayList;

/**
 *
 * @author harold
 */
public class FoodSupplierManagerDirectory {

    private final ArrayList<FoodSupplierManager> list;

    public FoodSupplierManagerDirectory() {
        this.list = new ArrayList<FoodSupplierManager>();
    }

    public ArrayList<FoodSupplierManager> getList() {
        return list;
    }

    public void add(FoodSupplierManager account) {
        this.list.add(account);
    }

    public FoodSupplierManager get(UserAccount ua) {
        for (FoodSupplierManager r : list) {
            if (r.getAccount().getUsername().equals(ua.getUsername())) {
                return r;
            }
        }
        return null;
    }

    public FoodSupplierManager search(String username) {
        for (FoodSupplierManager r : list) {
            if (r.getAccount().getUsername().equals(username)) {
                return r;
            }
        }
        return null;
    }

    public void delete(FoodSupplierManager account) {
         list.remove(account);
    }
}
