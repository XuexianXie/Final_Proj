/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BBX.Customer;

import BBX.UserAccount.UserAccount;
import java.util.ArrayList;

/**
 *
 * @author harold
 */
public class CustomerDirectory {
    
    private final ArrayList<Customer> list;

    public CustomerDirectory() {
        this.list = new ArrayList<Customer>();
    }

    public ArrayList<Customer> getList() {
        return list;
    }

    public void add(Customer account) {
        this.list.add(account);
    }

    public Customer get(UserAccount ua) {
        for (Customer r : list) {
            if (r.getAccount().getUsername().equals(ua.getUsername())) {
                return r;
            }
        }
        return null;
    }

    public Customer search(String username) {
        for (Customer r : list) {
            if (r.getAccount().getUsername().equals(username)) {
                return r;
            }
        }
        return null;
    }

    public void delete(Customer account) {
         list.remove(account);
    }
}
