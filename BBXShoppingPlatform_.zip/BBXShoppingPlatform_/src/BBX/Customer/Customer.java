/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BBX.Customer;

import BBX.food.FoodOrderDirectory;
import BBX.UserAccount.UserAccount;

/**
 *
 * @author harold
 */
public class Customer {
     private UserAccount account;
    private String name;
    private String phone;
    private String address;
    
    private FoodOrderDirectory orderDirectory;
    
    public Customer(UserAccount account, String name,String phone, String address) {
        this.account = account;
        this.name = name;
        this.phone = phone;
        this.address = address;
        
        orderDirectory = new FoodOrderDirectory();
    }

    public FoodOrderDirectory getOrderDirectory() {
        return orderDirectory;
    }
        
    public UserAccount getAccount() {
        return account;
    }

    public void setAccount(UserAccount account) {
        this.account = account;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
    
}
