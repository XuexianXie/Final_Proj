/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BBX;

import BBX.Customer.CustomerDirectory;
import BBX.DeliveryMan.DeliveryManDirectory;
import BBX.food.FoodSupplierManagerDirectory;
import BBX.Role.CustomerRole;
import BBX.Role.DeliveryManRole;
import BBX.Role.FoodOrderManagerRole;
import BBX.Role.FoodSupplierManagerRole;
import BBX.Role.Role;
import BBX.Role.SystemAdminRole;
import BBX.food.FoodOrderManagerDirectory;
import java.util.ArrayList;

public class Network extends Organization {

    private FoodSupplierManagerDirectory foodSupplierManagerDirectory;
    private FoodOrderManagerDirectory foodOrderManagerDirectory;

    private CustomerDirectory customerDirectory;
    private DeliveryManDirectory deliveryManDirectory;

    public Network(String name) {
        super(name);
        foodSupplierManagerDirectory = new FoodSupplierManagerDirectory();
        foodOrderManagerDirectory = new FoodOrderManagerDirectory();

        customerDirectory = new CustomerDirectory();
        deliveryManDirectory = new DeliveryManDirectory();
    }

    public FoodSupplierManagerDirectory getFoodSupplierDirectory() {
        return foodSupplierManagerDirectory;
    }
    
    public FoodOrderManagerDirectory getFoodOrderManagerDirectory() {
        return foodOrderManagerDirectory;
    }

    public CustomerDirectory getCustomerDirectory() {
        return customerDirectory;
    }

    public DeliveryManDirectory getDeliveryManDirectory() {
        return deliveryManDirectory;
    }

    @Override
    public ArrayList<Role> getSupportedRole() {
        ArrayList<Role> roleList = new ArrayList<Role>();
        roleList.add(new SystemAdminRole());
        roleList.add(new FoodSupplierManagerRole());
        roleList.add(new FoodOrderManagerRole());
        roleList.add(new CustomerRole());
        roleList.add(new DeliveryManRole());
        return roleList;
    }
}
