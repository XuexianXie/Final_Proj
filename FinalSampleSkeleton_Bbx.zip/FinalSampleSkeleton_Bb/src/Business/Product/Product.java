/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Product;

import java.util.ArrayList;

/**
 *
 * @author xuexianxie
 */
public class Product {
    private String name;
    private ArrayList<String> reviewList;
    private int Number;
    private int price;
    private int rate;
    private int id;
    private static int count = 1;
    
    public Product() {
        id = count;
        count++;
    }
    
    public ArrayList<String> getReviewList() {
        return reviewList;
    }
    
    public void setReviewList(ArrayList<String> arr) {
        reviewList = arr;
    }
    
    public void addReview(String review){
        reviewList.add(review);
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getRate() {
        return rate;
    }

    public void setRate(int rate) {
        this.rate = rate;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNumber() {
        return Number;
    }

    public void setNumber(int Number) {
        this.Number = Number;
    }
    
    
    
}
